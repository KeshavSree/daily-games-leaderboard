"use strict";
(() => {
  // lib/games.ts
  var gameNames = {
    linkdle: "Linkdle",
    farflung: "Farflung",
    travle: "Travle",
    animillion: "Animillion",
    maptap: "MapTap",
    chainle: "Chainle",
    krillion: "Krillion"
  };
  var defaultSettings = {
    timezone: "America/Indiana/Indianapolis",
    chainleAnchorDate: "2026-11-18",
    chainleAnchorNumber: 91,
    krillionAnchorDate: "2026-11-18",
    krillionAnchorNumber: 126,
    animillionAnchorDate: "2026-11-18",
    animillionAnchorNumber: 24,
    farflungAnchorDate: "2026-11-18",
    farflungAnchorNumber: 45
  };
  function dateInZone(now = /* @__PURE__ */ new Date(), timezone = defaultSettings.timezone) {
    return new Intl.DateTimeFormat("en-CA", {
      timeZone: timezone,
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    }).format(now);
  }
  function puzzleNumber(date, settings = defaultSettings) {
    return settings.chainleAnchorNumber + Math.round(
      (Date.parse(date + "T12:00:00Z") - Date.parse(settings.chainleAnchorDate + "T12:00:00Z")) / 864e5
    );
  }
  function krillionPuzzleNumber(date, settings = defaultSettings) {
    return settings.krillionAnchorNumber + Math.round(
      (Date.parse(date + "T12:00:00Z") - Date.parse(settings.krillionAnchorDate + "T12:00:00Z")) / 864e5
    );
  }
  function animillionPuzzleNumber(date, settings = defaultSettings) {
    return settings.animillionAnchorNumber + Math.round(
      (Date.parse(date + "T12:00:00Z") - Date.parse(settings.animillionAnchorDate + "T12:00:00Z")) / 864e5
    );
  }
  function farflungPuzzleNumber(date, settings = defaultSettings) {
    return settings.farflungAnchorNumber + Math.round(
      (Date.parse(date + "T12:00:00Z") - Date.parse(settings.farflungAnchorDate + "T12:00:00Z")) / 864e5
    );
  }
  function parseScore(raw, date, settings = defaultSettings) {
    if (!raw.trim()) throw new Error("Paste a score first.");
    if (raw.length > 4e3) throw new Error("Share text is too long.");
    const text = raw.replace(/\r\n?/g, "\n").trim();
    const isMap = /(?:www\.)?maptap\.gg\b/i.test(text);
    const isChain = /chainle\s*#/i.test(text);
    const isKrillion = /krillion\s*#/i.test(text);
    const isLinkdle = /\blinkdle\b/i.test(text);
    const isTravle = /^(?:Travle[ \t]+\d{4}-\d{2}-\d{2}|#travle\b)/im.test(text);
    const isFarflung = /\bfarflung\b/i.test(text);
    const isAnimillion = /\banimillion\b/i.test(text);
    if ([
      isMap,
      isChain,
      isKrillion,
      isLinkdle,
      isAnimillion,
      isFarflung,
      isTravle
    ].filter(Boolean).length > 1)
      throw new Error("Submit one game at a time.");
    if (isTravle) {
      const result = /^Travle (\d{4}-\d{2}-\d{2})\n([^\n→]+) → ([^\n→]+)\n(\d+) guesses? \(\+(\d+)\)$/i.exec(
        text
      );
      if (!result)
        throw new Error("Use the Daily extension on your completed Travle game.");
      const [, resultDate, start, end, total, extra] = result;
      if (resultDate !== date) throw new Error("Only today\u2019s Travle is open.");
      const route = [start, end].map(
        (country) => country.normalize("NFKC").trim().replace(/\s+/g, " ").toLowerCase()
      );
      if (route.some((country) => !country || country.length > 100) || route[0] === route[1])
        throw new Error("Invalid Travle route.");
      const guesses = Number(total);
      const score = Number(extra);
      if (!Number.isSafeInteger(guesses) || guesses > 2147483647 || score > guesses)
        throw new Error("Invalid Travle guess count.");
      return {
        game: "travle",
        score,
        puzzleKey: JSON.stringify([date, ...route]),
        date
      };
    }
    if (isFarflung) {
      const share = /^Farflung(?:[ \t]+Expedition)?[ \t]*#(\d+)[ \t]*\n[ \t]*(\d{1,3}(?:,\d{3})+|\d+)[ \t]*km(?:\nhttps:\/\/(?:www\.)?farflung\.game\/?)?$/i.exec(
        text
      );
      if (!share) throw new Error("Paste a Farflung result.");
      const number = Number(share[1]);
      const score = Number(share[2].replaceAll(",", ""));
      if (!Number.isSafeInteger(score) || score < 0 || score > 2147483647)
        throw new Error("Invalid Farflung distance.");
      if (number !== farflungPuzzleNumber(date, settings))
        throw new Error("Only today\u2019s Farflung expedition is open.");
      return { game: "farflung", score, puzzleKey: String(number), date };
    }
    if (isAnimillion) {
      const headers = [
        ...text.matchAll(
          /^ANIMILLION\s*[·•]\s*CLIMB\s*#(\d+)\s*[·•]\s*Floor\s+(\d+)\/700[ \t]*$/gim
        )
      ];
      if (headers.length !== 1)
        throw new Error("Paste the full Animillion share text.");
      const number = Number(headers[0][1]);
      const score = Number(headers[0][2]);
      if (!Number.isSafeInteger(score) || score < 0 || score > 700)
        throw new Error("Animillion scores must be 0\u2013700.");
      if (number !== animillionPuzzleNumber(date, settings))
        throw new Error("Only today\u2019s Animillion climb is open.");
      return { game: "animillion", score, puzzleKey: String(number), date };
    }
    if (isLinkdle) {
      const share = /^I solved today['’]s linkdle[ \t]+\(([^()\n→]+)→([^()\n→]+)\)[ \t]+in[ \t]+(\d+)[ \t]+jumps?![ \t]*🎉[ \t]+https:\/\/(?:www\.)?linkdle\.com\/en\/?$/i.exec(
        text
      );
      if (!share) throw new Error("Paste the full Linkdle share text.");
      const words = [share[1], share[2]].map(
        (word) => word.normalize("NFKC").trim().replace(/\s+/g, " ").toLowerCase()
      );
      if (words.some((word) => !word || word.length > 100))
        throw new Error("Invalid Linkdle words.");
      const score = Number(share[3]);
      if (!Number.isSafeInteger(score) || score < 1 || score > 2147483647)
        throw new Error("Invalid Linkdle jump count.");
      return {
        game: "linkdle",
        score,
        puzzleKey: JSON.stringify([date, ...words]),
        date
      };
    }
    if (isMap) {
      const headers = [
        ...text.matchAll(
          /^(?:https?:\/\/)?(?:www\.)?maptap\.gg\/?\s+([A-Za-z]+)\s+(\d{1,2})(?:,?\s+(\d{4}))?\s*$/gim
        )
      ];
      const totals = [
        ...text.matchAll(/^Final score:\s*(\d{1,3}(?:,\d{3})+|\d+)\s*$/gim)
      ];
      if (headers.length !== 1 || totals.length !== 1)
        throw new Error("Paste the full MapTap share text.");
      const months = [
        "january",
        "february",
        "march",
        "april",
        "may",
        "june",
        "july",
        "august",
        "september",
        "october",
        "november",
        "december"
      ];
      const [, month, day, year] = headers[0];
      const expected = `${year || date.slice(0, 4)}-${String(months.indexOf(month.toLowerCase()) + 1).padStart(2, "0")}-${day.padStart(2, "0")}`;
      if (expected !== date) throw new Error("Only today\u2019s puzzle is open.");
      const score = Number(totals[0][1].replaceAll(",", ""));
      if (!Number.isSafeInteger(score) || score < 0 || score > 1e3)
        throw new Error("MapTap scores must be 0\u20131,000.");
      return { game: "maptap", score, puzzleKey: date, date };
    }
    if (isChain) {
      const headers = [
        ...text.matchAll(
          /^Chainle\s*#(\d+)\s*[·•]\s*(\d{1,3}(?:,\d{3})+|\d+)\s*🔗\s*$/gim
        )
      ];
      if (headers.length !== 1 || !/^https:\/\/(?:www\.)?chainle\.io\/?\s*$/im.test(text))
        throw new Error("Paste the full Chainle share text.");
      const number = Number(headers[0][1]);
      const score = Number(headers[0][2].replaceAll(",", ""));
      if (!Number.isSafeInteger(score) || score < 0 || score > 5e3)
        throw new Error("Chainle scores must be 0\u20135,000.");
      if (number !== puzzleNumber(date, settings))
        throw new Error("Only today\u2019s Chainle puzzle is open.");
      return { game: "chainle", score, puzzleKey: String(number), date };
    }
    if (isKrillion) {
      const headers = [
        ...text.matchAll(/^Krillion[ \t]*#(\d+)[ \t]*🦐[ \t]*$/gim)
      ];
      const share = /^Krillion[ \t]*#(\d+)[ \t]*🦐[ \t]*\n[ \t]*(\d+)[ \t]*(?:\n|$)/i.exec(
        text
      );
      const totals = [...text.matchAll(/^[ \t]*\d+[ \t]*$/gm)];
      if (headers.length !== 1 || !share || totals.length !== 1)
        throw new Error("Paste the full Krillion share text.");
      const number = Number(share[1]);
      const score = Number(share[2]);
      if (!Number.isSafeInteger(score) || score < 0 || score > 700)
        throw new Error("Krillion scores must be 0\u2013700.");
      if (number !== krillionPuzzleNumber(date, settings))
        throw new Error("Only today\u2019s Krillion puzzle is open.");
      return { game: "krillion", score, puzzleKey: String(number), date };
    }
    throw new Error(
      "Use a Krillion, Chainle, MapTap, Linkdle, Animillion, or Farflung share."
    );
  }
  function formatScore(game, score) {
    const value = score.toLocaleString("en-US");
    if (game === "travle") return `+${value}`;
    return game === "farflung" ? `${value} km` : game === "linkdle" ? `${value} ${score === 1 ? "jump" : "jumps"}` : value;
  }

  // extension/src/config.js
  var GAME_HOSTS = {
    "travle.earth": "travle",
    "farflung.game": "farflung",
    "www.farflung.game": "farflung",
    "animillion.app": "animillion",
    "www.animillion.app": "animillion",
    "krillion.io": "krillion",
    "www.krillion.io": "krillion",
    "chainle.io": "chainle",
    "www.chainle.io": "chainle",
    "maptap.gg": "maptap",
    "www.maptap.gg": "maptap",
    "linkdle.com": "linkdle"
  };

  // extension/src/detect.js
  function detectResult(text, hostname, date = dateInZone(), pageDate2 = date) {
    const game = GAME_HOSTS[hostname];
    if (!game || typeof text !== "string") return null;
    text = text.replace(/\r\n?/g, "\n").replace(/\u00a0/g, " ");
    const candidates = [];
    if (game === "travle") {
      const route = /^Today I['’]d like to\s+travle\s+from\s+([^\n]+?)\s+to\s+([^\n]+)$/im.exec(
        text
      );
      const result = /^Success![^\n]*\n[ \t]*(\d+) guesses?[ \t]*\(\+(\d+)\)[ \t]*$/im.exec(
        text
      );
      if (route && result)
        candidates.push(
          `Travle ${pageDate2}
${route[1].trim()} \u2192 ${route[2].trim()}
${result[1]} guesses (+${result[2]})`
        );
    }
    if (game === "farflung") {
      for (const result of text.matchAll(
        /Farflung(?:[ \t]+Expedition)?[ \t]*#\d+[ \t]*\n[ \t]*[\d,]+[ \t]*km/gi
      ))
        candidates.push(result[0]);
      const completed = /Expedition[ \t]*#(\d+)\s+Complete\s+([\d,]+)\s*km/i.exec(
        text
      );
      if (completed)
        candidates.push(`Farflung #${completed[1]}
${completed[2]} km`);
    }
    if (game === "animillion") {
      candidates.push(
        ...[
          ...text.matchAll(
            /ANIMILLION[ \t]*[·•][ \t]*CLIMB[ \t]*#\d+[ \t]*[·•][ \t]*Floor[ \t]+\d+\/700/gi
          )
        ].map((match) => match[0])
      );
      for (const result of text.matchAll(
        /CLIMB[ \t]*#(\d+)[ \t]*[·•][ \t]*YOU REACHED\s+FLOOR[ \t]+(\d+)/gi
      ))
        candidates.push(
          `ANIMILLION \xB7 CLIMB #${result[1]} \xB7 Floor ${result[2]}/700`
        );
    }
    if (game === "linkdle") {
      const jumps = /Jumps[^\n]*\n\s*(\d+)/i.exec(text);
      const path = /Path[^\n]*\n([^]*?)(?=\nCan you do better|\nTry again)/i.exec(
        text
      );
      if (/You have won/i.test(text) && /Next linkdle in/i.test(text) && jumps && path) {
        const words = path[1].split(/\s*\n\s*arrow_forward\s*\n\s*/);
        if (words.length > 1)
          candidates.push(
            `I solved today's linkdle (${words[0].trim()} \u2192 ${words.at(-1).trim()}) in ${jumps[1]} jumps! \u{1F389} https://linkdle.com/en`
          );
      }
      const match = /I solved today['’]s linkdle[^\n]*?in\s+\d+\s+jumps?!\s*🎉(?:\s+https:\/\/(?:www\.)?linkdle\.com\/en\/?)?/i.exec(
        text
      );
      if (match)
        candidates.push(
          match[0].includes("https://") ? match[0] : match[0] + " https://linkdle.com/en"
        );
    }
    if (game === "chainle") {
      const completed = /puzzle\s+(\d+)\s+([\d,]+)\s+of\s+5,?000/i.exec(text);
      if (completed && /(?:Share|Continue unlimited)/i.test(text))
        candidates.push(
          `Chainle #${completed[1]} \xB7 ${completed[2]} \u{1F517}
https://chainle.io`
        );
      const matches = [...text.matchAll(/Chainle\s*#\d+\s*[·•]\s*[\d,]+\s*🔗/gi)];
      for (const match of matches)
        candidates.push(match[0] + "\nhttps://chainle.io");
    }
    if (game === "krillion") {
      const matches = [
        ...text.matchAll(
          /Krillion[ \t]*#\d+[ \t]*🦐[ \t]*\n\s*\d+[ \t]*(?=\n|$)/gi
        )
      ];
      candidates.push(...matches.map((match) => match[0]));
      for (const result of text.matchAll(
        /\bDive[ \t]*#[ \t]*(\d+)[ \t]+complete[ \t]*\n[ \t]*(\d+)[ \t]*(?=\n|$)/gi
      )) {
        candidates.push(`Krillion #${result[1]} \u{1F990}
${result[2]}`);
      }
    }
    if (game === "maptap") {
      const matches = [
        ...text.matchAll(
          /(?:www\.)?maptap\.gg\/?\s+[A-Za-z]+\s+\d{1,2}(?:,?\s+\d{4})?[^]*?Final score:\s*[\d,]+/gi
        )
      ];
      candidates.push(...matches.map((match) => match[0]));
      const screenDate = /\b(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+(\d{1,2}),\s*(\d{4})/i.exec(
        text
      );
      const total = /(?:^|\n)SCORE\s*\n\s*(\d+)(?=\n|$)/i.exec(text);
      if (screenDate && total && /Share your score/i.test(text)) {
        const months = [
          "January",
          "February",
          "March",
          "April",
          "May",
          "June",
          "July",
          "August",
          "September",
          "October",
          "November",
          "December"
        ];
        const month = months.find(
          (value) => value.toLowerCase().startsWith(screenDate[1].toLowerCase())
        );
        candidates.push(
          `www.maptap.gg ${month} ${screenDate[2]}, ${screenDate[3]}
Final score: ${total[1]}`
        );
      }
      const label2 = (/* @__PURE__ */ new Date(date + "T12:00:00Z")).toLocaleDateString("en-US", {
        month: "long",
        day: "numeric",
        timeZone: "UTC"
      });
      const final = /Final score:\s*([\d,]+)/i.exec(text);
      if (final && text.includes(label2))
        candidates.push(`www.maptap.gg ${label2}
Final score: ${final[1]}`);
    }
    const valid = [];
    for (const raw of candidates) {
      try {
        const parsed = parseScore(raw, date);
        if (parsed.game === game)
          valid.push({
            raw,
            ...parsed,
            name: gameNames[game],
            display: formatScore(game, parsed.score)
          });
      } catch {
      }
    }
    const keys = new Set(
      valid.map((result) => JSON.stringify([result.puzzleKey, result.score]))
    );
    return keys.size === 1 ? valid[0] : null;
  }

  // extension/src/content.js
  var pageDate = dateInZone();
  var candidate = null;
  var captured = "";
  var capturedDate = "";
  var host;
  var root;
  var label;
  var button;
  var status;
  var busy = false;
  var dismissed = "";
  var submitted = "";
  var key = (result) => result ? JSON.stringify([result.game, result.date, result.puzzleKey, result.score]) : "";
  function mount() {
    host = document.createElement("div");
    host.id = "daily-extension";
    root = host.attachShadow({ mode: "closed" });
    root.innerHTML = `<style>
    :host{all:initial;position:fixed;bottom:24px;right:24px;z-index:2147483647;font:14px system-ui;color:#eee}
    section{background:#090909;border:1px solid #444;padding:16px;min-width:220px;box-shadow:0 8px 32px #0006}
    header{display:flex;justify-content:space-between;align-items:center;gap:24px;margin-bottom:12px}
    b{font-size:19px;letter-spacing:-1px}em{color:#c9a44c;font-style:normal}
    button{font:inherit;cursor:pointer;border:1px solid #555;background:#e8e8e4;color:#111;padding:10px 14px;width:100%}
    button:disabled{opacity:.5;cursor:default}.close{background:transparent;border:0;color:#aaa;width:auto;padding:0 3px;font-size:20px}
    p{margin:0 0 12px}output{display:block;max-width:280px;font-size:12px;line-height:1.5;color:#aaa}output:not(:empty){margin-top:10px}
  </style><section aria-label="Daily score"><header><b>daily<em>/</em></b><button class="close" aria-label="Dismiss">\xD7</button></header><p></p><button class="submit">Submit to Daily</button><output aria-live="polite"></output></section>`;
    label = root.querySelector("p");
    button = root.querySelector(".submit");
    status = root.querySelector("output");
    button.addEventListener("click", submit);
    root.querySelector(".close").addEventListener("click", () => {
      dismissed = key(candidate);
      host.remove();
    });
    document.documentElement.append(host);
  }
  function show(next) {
    if (!next) return;
    const changed = key(next) !== key(candidate);
    candidate = next;
    if (dismissed === key(next)) return;
    if (!host?.isConnected) mount();
    if (changed || !label.textContent) {
      label.textContent = `${next.name} / ${next.display}`;
      status.textContent = "";
      button.disabled = busy || submitted === key(next);
      button.textContent = submitted === key(next) ? "Submitted" : "Submit to Daily";
    }
  }
  async function submit() {
    if (busy || !candidate) return;
    const current = candidate;
    busy = true;
    button.disabled = true;
    status.textContent = "Submitting\u2026";
    try {
      const result = await chrome.runtime.sendMessage({
        type: "daily:submit",
        raw: current.raw
      });
      if (!result?.ok) throw new Error(result?.error || "Could not submit.");
      submitted = key(current);
      button.textContent = "Submitted";
      status.textContent = "";
    } catch (error) {
      status.textContent = error.message;
    } finally {
      busy = false;
      button.disabled = submitted === key(candidate);
    }
  }
  function scan() {
    if (busy) return;
    const today = dateInZone();
    if (capturedDate !== today) captured = "";
    if (candidate && candidate.date !== today) {
      candidate = null;
      host?.remove();
    }
    const visible = document.body?.innerText || "";
    const texts = [
      document.querySelector('[role="dialog"]')?.innerText || "",
      visible.slice(0, 2e5)
    ];
    for (const el of document.querySelectorAll(
      "[title],textarea,input[readonly]"
    )) {
      const value = el.getAttribute("title") || el.value || "";
      if (value.length <= 4e3) texts.push(value);
    }
    let next = detectResult(texts.join("\n"), location.hostname, today, pageDate);
    if (!next && captured) next = detectResult(captured, location.hostname);
    if (next) show(next);
    else {
      candidate = null;
      host?.remove();
    }
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== location.origin || event.data?.type !== "daily:share")
      return;
    const raw = event.data.text;
    if (typeof raw !== "string" || raw.length > 4e3) return;
    const next = detectResult(raw, location.hostname);
    if (next) {
      captured = raw;
      capturedDate = dateInZone();
      show(next);
    }
  });
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (sender.id !== chrome.runtime.id) return;
    if (message.type === "result") {
      scan();
      reply({ result: candidate });
    }
  });
  var timer;
  new MutationObserver(() => {
    if (timer) return;
    timer = setTimeout(() => {
      timer = null;
      scan();
    }, 250);
  }).observe(document.documentElement, {
    subtree: true,
    childList: true,
    characterData: true
  });
  scan();
})();

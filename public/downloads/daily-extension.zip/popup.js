"use strict";
(() => {
  // extension/src/popup.js
  var label = document.querySelector("#result");
  var button = document.querySelector("#submit");
  var status = document.querySelector("#status");
  var candidate;
  (async () => {
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true
      });
      const response = await chrome.tabs.sendMessage(tab.id, { type: "result" });
      candidate = response?.result;
    } catch {
    }
    label.textContent = candidate ? `${candidate.name} / ${candidate.display}` : "Finish a supported game. If needed, click the game\u2019s Share button.";
    button.hidden = !candidate;
  })();
  button.addEventListener("click", async () => {
    if (!candidate) return;
    button.disabled = true;
    status.textContent = "Submitting\u2026";
    try {
      const result = await chrome.runtime.sendMessage({
        type: "daily:submit",
        raw: candidate.raw
      });
      if (!result?.ok) throw new Error(result?.error || "Could not submit.");
      button.textContent = "Submitted";
      status.textContent = "";
    } catch (error) {
      status.textContent = error.message;
      button.disabled = false;
    }
  });
  document.querySelector("#login").addEventListener(
    "click",
    () => chrome.runtime.sendMessage({ type: "daily:login" })
  );
  var account = document.querySelector("#account");
  var login = document.querySelector("#login");
  async function refreshAccount() {
    login.hidden = true;
    try {
      const result = await chrome.runtime.sendMessage({ type: "daily:status" });
      if (result?.ok) {
        account.textContent = `Logged in as ${result.name}`;
      } else if (result?.authenticated === false) {
        account.textContent = "";
        login.hidden = false;
      } else {
        account.textContent = "Could not check account";
      }
    } catch {
      account.textContent = "Could not check account";
    }
  }
  void refreshAccount();
})();
